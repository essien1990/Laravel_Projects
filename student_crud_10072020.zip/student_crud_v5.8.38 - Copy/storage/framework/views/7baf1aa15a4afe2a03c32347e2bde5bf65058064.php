<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <h3 class="text-center"><strong>STUDENT DATA</strong> <a href="<?php echo e(route('student.create')); ?>" class="btn btn-primary btn-sm pull-right"> Add <i class="fa fa-plus fa-1x"></i></a></h3>
        <hr>
        <br/>
        <?php if($message = Session::get('success')): ?>
             <div class="alert alert-dismissible alert-success" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
                <p><?php echo e($message); ?></p>
             </div>
        <?php endif; ?>
        <table class="table table-bordered table-striped">
            <tr>
                <th>FIRST NAME</th>
                <th>LAST NAME</th>
                <th>ACTION</td>
            </tr>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($student['first_name']); ?></td>
                    <td><?php echo e($student['last_name']); ?></td>
                    <td><a href="<?php echo e(action('StudentController@edit', $student['id'])); ?>" class="btn btn-sm btn-info"><i class="fa fa-edit fa-1x"></i></a></td>
                    <td>
                    <form method="POST" action="<?php echo e(action('StudentController@destroy', $student['id'])); ?>" class="delete-form">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="DELETE">
                       <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash fa-1x"></i></button>
                    </form>
                </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\student_crud_v5.8.38\resources\views/student/index.blade.php ENDPATH**/ ?>