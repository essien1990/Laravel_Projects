<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset("css/cosmo_bootstrap.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/font-awesome.min.css")); ?>">
    <title>Laravel CRUD</title>
</head>
<body>
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>


    <script src="<?php echo e(asset("js/jquery.min.js")); ?>"></script>
    <script src="<?php echo e(asset("js/bootstrap.min.js")); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\student_crud_v5.8.38\resources\views/master.blade.php ENDPATH**/ ?>