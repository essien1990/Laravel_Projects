<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h3 class="text-center"><strong>EDIT DATA</strong></h3>
            <hr>
            <br/>
            <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <form action="<?php echo e(action('StudentController@update',$id)); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="_method" value="PATCH">
                <div class="form-group">
                    <input type="text" value="<?php echo e($student->first_name); ?>" name="first_name" class="form-control" placeholder="Enter first name">
                </div>
                <div class="form-group">
                    <input type="text" value="<?php echo e($student->last_name); ?>" name="last_name" class="form-control" placeholder="Enter last name">
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-small btn-primary btn-block" value="Edit Data">
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\student_crud_v5.8.38\resources\views/student/edit.blade.php ENDPATH**/ ?>