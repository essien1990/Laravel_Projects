@extends('master')

@section('content')

<div class="row">
    <div class="col-md-12">
        <h3 class="text-center"><strong>STUDENT DATA</strong> <a href="{{ route('student.create')}}" class="btn btn-primary btn-sm pull-right"> Add <i class="fa fa-plus fa-1x"></i></a></h3>
        <hr>
        <br/>
        @if($message = Session::get('success'))
             <div class="alert alert-dismissible alert-success" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
                <p>{{$message}}</p>
             </div>
        @endif
        <table class="table table-bordered table-striped">
            <tr>
                <th>FIRST NAME</th>
                <th>LAST NAME</th>
                <th>ACTION</td>
            </tr>
            @foreach($students as $student)
                <tr>
                    <td>{{ $student['first_name'] }}</td>
                    <td>{{ $student['last_name'] }}</td>
                    <td><a href="{{ action('StudentController@edit', $student['id'])}}" class="btn btn-sm btn-info"><i class="fa fa-edit fa-1x"></i></a></td>
                    <td>
                    <form method="POST" action="{{ action('StudentController@destroy', $student['id'])}}" class="delete-form">
                        {{ csrf_field()}}
                        <input type="hidden" name="_method" value="DELETE">
                       <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash fa-1x"></i></button>
                    </form>
                </td>
                </tr>
            @endforeach
        </table>
    </div>
</div>

@endsection
